package com.example.z

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.z.ui.theme.ZTheme
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val sm1 = LatLng(14.6043613, 121.018829)
            val sm2 = LatLng(14.6568, 121.0304)
            val sm3 = LatLng(14.5352, 120.9819)

            val cameraPositionState = rememberCameraPositionState {
                position = CameraPosition.fromLatLngZoom(sm1, 15f)
            }
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState
            ) {
                Marker(
                    state = MarkerState(position = sm1),
                    title = "Sta Mesa titlee",
                    snippet = "Snippetko"
                )
                Marker(
                    state = MarkerState(position = sm2),
                    title = "NorthEdsa titlee",
                    snippet = "Snippetko"
                )
                Marker(
                    state = MarkerState(position = sm3),
                    title = "MOAA titlee",
                    snippet = "Snippetko"
                )
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    ZTheme {
        Greeting("Android")
    }
}