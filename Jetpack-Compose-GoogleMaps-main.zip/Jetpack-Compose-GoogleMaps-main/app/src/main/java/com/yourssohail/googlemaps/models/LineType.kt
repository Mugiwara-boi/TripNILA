package com.yourssohail.googlemaps.models

enum class LineType {
    POLYLINE,
    POLYGON
}
