package com.example.composewebview

import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.composewebview.ui.theme.ComposeWebviewTheme
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WebViewPage("https://www.google.com/maps/search/attractions+near+manila+hotel/@14.5804141,120.9761593,15z/data=!3m1!4b1?entry=ttu")

        }
    }
}

//@Composable
//fun WebViewPage(url:String){
//    AndroidView(factory = {
//        WebView(it).apply {
//            layoutParams = ViewGroup.LayoutParams(
//                ViewGroup.LayoutParams.MATCH_PARENT,
//                ViewGroup.LayoutParams.MATCH_PARENT
//            )
//            settings.javaScriptEnabled = true
//            settings.setSupportZoom(true)
//            webViewClient = WebViewClient()
//            loadUrl(url)
//        }
//    }, update = {
//        it.loadUrl(url)
//    })
//}

@Composable
fun WebViewPage(url: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
    ) {
        Text(
            text = "Nearby Attractions",
//            style = MaterialTheme.typography.h6,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(16.dp)
        )

        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    settings.javaScriptEnabled = true
                    settings.setSupportZoom(true)
                    webViewClient = WebViewClient()
                    loadUrl(url)
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
        )

        Text(
            text = "Text at the Bottom",
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .fillMaxSize()
                .height(50.dp) // Adjust the height as needed
                .padding(16.dp)
        )

    }
}

@Preview(showBackground = true)
@Composable
fun PreviewWebViewPage() {
    ComposeWebviewTheme {
        WebViewPage("https://www.google.com/maps/search/attractions+near+manila+hotel/@14.5804141,120.9761593,15z/data=!3m1!4b1?entry=ttu")
    }
}
