package com.example.composewebview

import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.composewebview.ui.theme.ComposeWebviewTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WebViewPage("https://www.google.com/maps/@14.5976056,120.9908505,13z?entry=ttu")
        }
    }
}

@Composable
fun WebViewPage(initialUrl: String) {
    var currentUrl by remember { mutableStateOf(initialUrl) }

    Column(
        modifier = Modifier
            .fillMaxSize()
    ) {
        Text(
            text = "Zoom and Hover Map to Business vicinity, long press to add marker",
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(16.dp)
        )

        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        0
                    )
                    settings.javaScriptEnabled = true
                    settings.setSupportZoom(true)
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            currentUrl = url.orEmpty()
                        }
                    }
                    loadUrl(initialUrl)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(500.dp)
        )

        val (latitude, longitude) = extractLatLngFromUrl(currentUrl)
        Text(
            text = "Current URL: $currentUrl\nLatitude: $latitude, Longitude: $longitude",
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        )
    }
}

fun extractLatLngFromUrl(url: String): Pair<String, String> {
    val pattern = Regex("@([-+]?\\d*\\.?\\d+),([-+]?\\d*\\.?\\d+),?")
    val matchResult = pattern.find(url)
    val (lat, lng) = matchResult?.destructured?.let { (latitude, longitude) ->
        latitude to longitude
    } ?: "" to ""
    return lat to lng
}

