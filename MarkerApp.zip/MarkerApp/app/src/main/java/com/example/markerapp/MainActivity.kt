package com.example.markerapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.markerapp.ui.theme.MarkerAppTheme
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState

import androidx.compose.runtime.*
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val cameraPositionState = rememberCameraPositionState {
                position = CameraPosition.fromLatLngZoom(LatLng(14.6043613, 121.018829), 15f)
            }

            // State to store user-added markers
            var userMarkers by remember { mutableStateOf(emptyList<LatLng>()) }

            // State to indicate whether deletion mode is active
            var deletionMode by remember { mutableStateOf(false) }

            // State to store the index of the clicked marker to delete
            var markerToDelete by remember { mutableStateOf<Int?>(null) }

            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Top
            ) {
                Button(
                    onClick = {
                        // Toggle deletion mode
                        deletionMode = !deletionMode
                    },
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(text = if (deletionMode) "Exit Deletion Mode" else "Enter Deletion Mode")
                }

                GoogleMap(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    cameraPositionState = cameraPositionState,
                    onMapClick = { position ->
                        if (!deletionMode) {
                            // Add the clicked position to the list of user markers
                            userMarkers = userMarkers + position
                        }
                    }
                ) {
                    // Display existing markers
                    Marker(
                        state = MarkerState(position = LatLng(14.6043613, 121.018829)),
                        title = "Sta Mesa titlee",
                        snippet = "Snippetko"
                    )
                    Marker(
                        state = MarkerState(position = LatLng(14.6568, 121.0304)),
                        title = "NorthEdsa titlee",
                        snippet = "Snippetko"
                    )
                    Marker(
                        state = MarkerState(position = LatLng(14.5352, 120.9819)),
                        title = "MOAA titlee",
                        snippet = "Snippetko"
                    )

                    // Display user-added markers
                    userMarkers.forEachIndexed { index, position ->
                        Marker(
                            state = MarkerState(position = position),
                            title = "User Marker $index",
                            snippet = "Added by the user",
                            onClick = {
                                if (deletionMode) {
                                    // Set the index to delete the marker
                                    markerToDelete = index
                                    true // Return a boolean value indicating that the marker click is handled
                                } else {
                                    // Handle other click logic if needed
                                    false // Return false if the click is not handled for other scenarios
                                }
                            }
                        )
                    }

                    // Delete the marker if the index is not null
                    markerToDelete?.let { index ->
                        userMarkers = userMarkers.toMutableList().apply { removeAt(index) }
                        markerToDelete = null
                    }
                }
            }
        }
    }
}